import './App.css'
import { Inpussst } from './Inpussst'
function App() {
  return (
    <div className="App">
      {/* <h1 onClick={cli}>点我</h1> */}
      <Inpussst></Inpussst>
      {/* 上传文件
      <Inpussst></Inpussst>
    */}
      {/* <input type="file" accept="image/*" placeholder="上传你选择的图片" id="image-upload-hidden" onChange={loadFile} multiple /> */}
    </div>
  )
}

export default App
